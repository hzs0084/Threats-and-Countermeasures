#!/bin/bash
# ACME IT Corp - Web Deploy Script
# Run from the directory containing this script as: sudo bash deploy.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[*] Deploying ACME IT Corp website..."

# Wipe web root
rm -rf /var/www/html/*

# Copy site files
cp -r "$SCRIPT_DIR/acme/"* /var/www/html/

# Create required directories and files
mkdir -p /var/www/html/uploads
touch /var/www/html/data/messages.txt
touch /var/www/html/data/uploads.txt

# Set ownership
chown -R www-data:www-data /var/www/html/

# Set permissions
chmod -R 755 /var/www/html/
chmod 775 /var/www/html/uploads
chmod 664 /var/www/html/data/messages.txt
chmod 664 /var/www/html/data/uploads.txt

# users.txt readable only by www-data
chmod 640 /var/www/html/data/users.txt

# Remove any leftover dirs
rm -rf /var/www/html/internal 2>/dev/null || true
rm -rf /var/www/html/backups 2>/dev/null || true

# Enable Apache modules
a2enmod rewrite 2>/dev/null || true
PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || echo "")
[ -n "$PHP_VER" ] && a2enmod "php$PHP_VER" 2>/dev/null || true
systemctl restart apache2

echo "[+] Deploy complete."
echo ""
echo "Verifying..."
curl -s http://127.0.0.1/ | grep -o "ACME IT Corp" | head -1 && echo "[+] Site is live." || echo "[-] Site check failed."
echo ""
echo "Final structure:"
find /var/www/html -not -path '*/uploads/*' -type f | sort
