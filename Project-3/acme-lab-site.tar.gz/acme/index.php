<?php require_once __DIR__ . '/_lib.php'; ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>ACME IT Corp • Staff Portal</title>
  <link rel="stylesheet" href="<?= acme_base_url() ?>/assets/style.css">
</head>
<body>
  <div class="container">
    <div class="nav">
      <div class="brand">ACME IT Corp <span class="badge">internal</span></div>
      <div class="links">
        <a href="<?= acme_base_url() ?>/index.php">Home</a>
        <a href="<?= acme_base_url() ?>/contact.php">Support</a>
        <?php if (!empty($_SESSION['user'])): ?>
          <a href="<?= acme_base_url() ?>/dashboard.php">Dashboard</a>
          <a href="<?= acme_base_url() ?>/logout.php">Logout</a>
        <?php else: ?>
          <a href="<?= acme_base_url() ?>/login.php">Staff Login</a>
        <?php endif; ?>
      </div>
    </div>

    <div class="card">
      <div class="h1">ACME IT Corp — Internal Portal</div>
      <div class="p">
        IT services and managed solutions since 2002.<br>
        This portal is for authorized ACME staff only.
      </div>
      <hr>
      <div class="grid">
        <div class="card">
          <div class="h1" style="font-size:16px;">System Status</div>
          <div class="p">All systems nominal. Next maintenance window: Sunday 02:00.<br>
          Web services: <span style="color:#6fcf6f;">Online</span></div>
        </div>
        <div class="card">
          <div class="h1" style="font-size:16px;">Quick Links</div>
          <div class="p">
            <a href="<?= acme_base_url() ?>/login.php">Staff Login</a><br>
            <a href="<?= acme_base_url() ?>/contact.php">Submit Support Request</a>
          </div>
        </div>
      </div>
      <div class="footer">© <?= date('Y') ?> ACME IT Corp • Unauthorized access is prohibited and monitored.</div>
    </div>
  </div>
</body>
</html>
