<?php
require_once __DIR__ . '/_lib.php';
session_destroy();
header('Location: ' . acme_base_url() . '/login.php');
exit;
