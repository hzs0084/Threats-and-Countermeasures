<?php
require_once __DIR__ . '/_lib.php';
acme_require_login();
$user = $_SESSION['user'];
$role = $_SESSION['role'] ?? 'user';
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>ACME IT Corp • Dashboard</title>
  <link rel="stylesheet" href="<?= acme_base_url() ?>/assets/style.css">
</head>
<body>
  <div class="container">
    <div class="nav">
      <div class="brand">ACME IT Corp</div>
      <div class="links">
        <a href="<?= acme_base_url() ?>/index.php">Home</a>
        <a href="<?= acme_base_url() ?>/contact.php">Support</a>
        <a href="<?= acme_base_url() ?>/logout.php">Logout</a>
      </div>
    </div>

    <div class="card">
      <div class="h1">Welcome, <?= acme_h($user) ?></div>
      <div class="p">Role: <span class="badge"><?= acme_h($role) ?></span></div>

      <hr>
      <div class="grid">
        <div class="card">
          <div class="h1" style="font-size:16px;">File Upload</div>
          <div class="p">Submit internal documents and reports.</div>
          <div class="p"><a href="<?= acme_base_url() ?>/upload.php">Open Upload Portal</a></div>
        </div>

        <?php if (acme_is_admin()): ?>
        <div class="card">
          <div class="h1" style="font-size:16px;">Admin Panel</div>
          <div class="p">Review support tickets and manage internal tools.</div>
          <div class="p">
            <a href="<?= acme_base_url() ?>/admin/index.php">Admin Panel</a>
          </div>
        </div>
        <?php else: ?>
        <div class="card">
          <div class="h1" style="font-size:16px;">IT Helpdesk</div>
          <div class="p">Need elevated access or have an issue to report?</div>
          <div class="p"><a href="<?= acme_base_url() ?>/contact.php">Submit a request</a></div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</body>
</html>
