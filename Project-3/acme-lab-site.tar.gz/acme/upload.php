<?php
require_once __DIR__ . '/_lib.php';
acme_require_login();

// ----- Configuration -----
// NOTE: Files are stored in the web-accessible uploads directory.
$UPLOAD_DIR = __DIR__ . '/uploads';
$UPLOAD_LOG = __DIR__ . '/data/uploads.txt';

// Allowed file extensions (extension check only - no MIME validation)
$ALLOWED_EXT = ['pdf', 'png', 'jpg', 'jpeg', 'txt'];
$MAX_BYTES   = 2 * 1024 * 1024; // 2 MB

// Users permitted to upload
$allowed_upload_users = ['mitchmarcus', 'alicebrown', 'evejohnson', 'fongling'];

// ----- Helpers -----
function ensure_dir_exists(string $path): void {
  if (!is_dir($path)) {
    mkdir($path, 0755, true);
  }
}

function h(string $s): string {
  return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// ----- Access Control -----
$user = $_SESSION['user'] ?? '';
if (!in_array($user, $allowed_upload_users, true)) {
  http_response_code(403);
  exit('Access denied.');
}

// ----- Handle Upload -----
$err = '';
$ok  = '';
$last_uploaded_name = '';

ensure_dir_exists($UPLOAD_DIR);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!isset($_FILES['file']) || !is_array($_FILES['file'])) {
    $err = 'No file was provided.';
  } else {
    $f = $_FILES['file'];

    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
      $err = 'Upload error. Code: ' . (int)$f['error'];
    } elseif (($f['size'] ?? 0) > $MAX_BYTES) {
      $err = 'File too large. Maximum size is ' . ($MAX_BYTES / (1024*1024)) . ' MB.';
    } else {
      $originalName = $f['name'] ?? '';
      $tmpPath      = $f['tmp_name'] ?? '';

      // Extension-based validation only
      $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

      if (!in_array($ext, $ALLOWED_EXT, true)) {
        $err = 'File type not allowed. Accepted: ' . implode(', ', $ALLOWED_EXT);
      } elseif (!is_uploaded_file($tmpPath)) {
        $err = 'Invalid upload source.';
      } else {
        // Save with original filename into web-accessible directory
        $safeName = basename($originalName);
        $destPath = rtrim($UPLOAD_DIR, '/') . '/' . $safeName;

        if (!move_uploaded_file($tmpPath, $destPath)) {
          $err = 'Failed to save file.';
        } else {
          chmod($destPath, 0644);

          // Log the upload
          $ts   = date('Y-m-d H:i:s');
          $line = $ts . '|' . $user . '|' . $safeName . '|' . ($f['size'] ?? 0) . PHP_EOL;
          file_put_contents($UPLOAD_LOG, $line, FILE_APPEND | LOCK_EX);

          $ok = 'File uploaded successfully.';
          $last_uploaded_name = $safeName;
        }
      }
    }
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>ACME IT Corp • Upload Portal</title>
  <link rel="stylesheet" href="<?= acme_base_url() ?>/assets/style.css">
</head>
<body>
  <div class="container">
    <div class="nav">
      <div class="brand">ACME IT Corp <span class="badge">upload portal</span></div>
      <div class="links">
        <a href="<?= acme_base_url() ?>/index.php">Home</a>
        <a href="<?= acme_base_url() ?>/dashboard.php">Dashboard</a>
        <a href="<?= acme_base_url() ?>/logout.php">Logout</a>
      </div>
    </div>

    <div class="card">
      <div class="h1">File Upload</div>
      <div class="p">
        Submit internal reports and documents.<br>
        Accepted types: <?= h(implode(', ', $ALLOWED_EXT)) ?> &nbsp;|&nbsp;
        Max size: <?= h((string)($MAX_BYTES/(1024*1024))) ?> MB
      </div>

      <?php if ($err): ?>
        <div class="card" style="border-color:#5a2a2a;background:rgba(90,42,42,0.25);">
          <?= h($err) ?>
        </div>
      <?php endif; ?>

      <?php if ($ok): ?>
        <div class="card" style="border-color:#2b5a2a;background:rgba(43,90,42,0.25);">
          <?= h($ok) ?>
          <?php if ($last_uploaded_name): ?>
            <div class="p">Saved as: <span class="badge"><?= h($last_uploaded_name) ?></span></div>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <form method="post" enctype="multipart/form-data">
        <label>Select file</label>
        <input type="file" name="file" required>
        <button type="submit">Upload</button>
      </form>
      <hr>
    </div>
  </div>
</body>
</html>
