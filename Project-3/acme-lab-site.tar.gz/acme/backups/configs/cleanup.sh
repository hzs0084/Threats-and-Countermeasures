#!/bin/bash
# ACME IT Corp - Lab Reset Script
# Run as root before distributing OVA to students

echo "Starting lab cleanup..."

# Clear shell histories
> /root/.bash_history
history -c
> /home/alicebrown/.bash_history
> /home/evejohnson/.bash_history
> /home/claireredfield/.bash_history
> /home/fongling/.bash_history
> /home/mallorymartinez/.bash_history
# NOTE: Keep mitchmarcus and bobbarker histories - they are intentional breadcrumbs

# Remove tmp artifacts
rm -f /tmp/test* /tmp/rootbash /var/tmp/test*
rm -f /home/*/test* /home/*/*.bak /home/*/*.old
rm -f /var/www/html/uploads/*.php 2>/dev/null

# Remove vim swap files
find /home -name "*.swp" -o -name ".*.swp" -delete 2>/dev/null
find /var/www/html -name "*.swp" -o -name ".*.swp" -delete 2>/dev/null

echo "Cleanup complete."
echo ""
echo "Verify these intentional breadcrumbs still exist:"
echo "  /home/mitchmarcus/.bash_history     (FTP breadcrumb)"
echo "  /home/bobbarker/.bash_history       (rabbit hole SSHs)"
echo "  /home/claireredfield/.bash_history  (FTP connection to 172.16.0.2)"
echo "  /opt/legacy/python3-eve             (SUID binary for privesc)"
echo "  /opt/lab/ftp/                       (Docker FTP container)"
echo "  /var/www/html/internal/todo.txt     (upload vuln hint)"
echo "  /var/www/html/backups/configs/eve_config.txt (Eve SUID + FTP hints)"
