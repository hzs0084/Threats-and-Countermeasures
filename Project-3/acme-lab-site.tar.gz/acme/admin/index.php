<?php
require_once __DIR__ . '/../_lib.php';
acme_require_login();

if (!acme_is_admin()) {
  http_response_code(403);
  exit('Access denied.');
}

$user     = $_SESSION['user'];
$MSG_FILE = __DIR__ . '/../data/messages.txt';
$messages = [];

if (file_exists($MSG_FILE)) {
  $lines = file($MSG_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
  foreach ($lines as $line) {
    $parts = explode('|', $line, 3);
    if (count($parts) === 3) {
      $messages[] = [
        'ts'   => $parts[0],
        'user' => $parts[1],
        'msg'  => $parts[2],
      ];
    }
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>ACME IT Corp • Admin Panel</title>
  <link rel="stylesheet" href="/assets/style.css">
  <style>
    .msg-item { border-bottom: 1px solid #334; padding: 12px 0; }
    .meta { font-size: 0.82em; color: #888; margin-bottom: 4px; }
    .body { font-size: 1em; }
  </style>
</head>
<body>
  <div class="container">
    <div class="nav" style="border-bottom: 2px solid #c33;">
      <div class="brand" style="color:#e55;">ACME IT Corp <span class="badge">ADMIN</span></div>
      <div class="links">
        <a href="/">Back to Site</a>
        <a href="/logout.php">Logout</a>
      </div>
    </div>

    <div class="card">
      <div class="h1">Support Inbox</div>
      <div class="p">All submitted support requests — logged in from: <strong><?= htmlspecialchars($user) ?></strong></div>
      <hr>

      <?php if (empty($messages)): ?>
        <div class="p">No messages on record.</div>
      <?php else: ?>
        <?php foreach (array_reverse($messages) as $m): ?>
          <div class="msg-item">
            <div class="meta">
              <?= htmlspecialchars($m['ts']) ?> &nbsp;|&nbsp;
              <strong style="color:#aac4ff;"><?= htmlspecialchars($m['user']) ?></strong>
            </div>
            <div class="body">
              <?= $m['msg'] ?>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
