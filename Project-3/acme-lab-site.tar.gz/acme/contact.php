<?php
require_once __DIR__ . '/_lib.php';
acme_require_login();

$MSG_FILE = __DIR__ . '/data/messages.txt';
$err = '';
$ok  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $msg = $_POST['message'] ?? '';

  if (trim($msg) === '') {
    $err = 'Message cannot be empty.';
  } else {
    $user     = $_SESSION['user'];
    $ts       = date('Y-m-d H:i:s');
    $cleanMsg = str_replace(["\r", "\n", "|"], [" ", " ", " "], $msg);
    $line     = "$ts|$user|$cleanMsg\n";
    file_put_contents($MSG_FILE, $line, FILE_APPEND);
    $ok = 'Your message has been sent to the administrator.';
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>ACME IT Corp • Support</title>
  <link rel="stylesheet" href="<?= acme_base_url() ?>/assets/style.css">
</head>
<body>
  <div class="container">
    <div class="nav">
      <div class="brand">ACME IT Corp <span class="badge">support</span></div>
      <div class="links">
        <a href="<?= acme_base_url() ?>/index.php">Home</a>
        <a href="<?= acme_base_url() ?>/dashboard.php">Dashboard</a>
        <a href="<?= acme_base_url() ?>/logout.php">Logout</a>
      </div>
    </div>

    <div class="card">
      <div class="h1">Submit Support Request</div>
      <div class="p">
        Questions or access requests? Send a message to the IT administrator.<br>
        Responses are typically within one business day.
      </div>

      <?php if ($ok): ?>
        <div class="card" style="border-color:#2b5a2a;background:rgba(43,90,42,0.25);">
          <?= htmlspecialchars($ok) ?>
        </div>
      <?php endif; ?>

      <?php if ($err): ?>
        <div class="card" style="border-color:#5a2a2a;background:rgba(90,42,42,0.25);">
          <?= htmlspecialchars($err) ?>
        </div>
      <?php endif; ?>

      <form method="post">
        <label>Message</label>
        <textarea name="message" rows="5" required placeholder="Describe your issue or request..."></textarea>
        <button type="submit">Send Message</button>
      </form>
    </div>
  </div>
</body>
</html>
