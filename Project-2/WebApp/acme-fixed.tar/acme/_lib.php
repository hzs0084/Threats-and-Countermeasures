<?php
declare(strict_types=1);

session_start();

function acme_base_url(): string {
  return '';
}

function acme_require_login(): void {
  if (empty($_SESSION['user'])) {
    header('Location: ' . acme_base_url() . '/login.php');
    exit;
  }
}

function acme_is_admin(): bool {
  return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function acme_read_users(string $path): array {
  $users = [];
  if (!file_exists($path)) return $users;

  foreach (file($path, FILE_IGNORE_NEW_LINES) as $line) {
    $line = trim($line);
    if ($line === '' || str_starts_with($line, '#')) continue;
    [$u, $p, $r] = array_pad(explode(':', $line, 3), 3, '');
    $users[$u] = ['pass' => $p, 'role' => $r ?: 'user'];
  }
  return $users;
}

function acme_h(string $s): string {
  return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

