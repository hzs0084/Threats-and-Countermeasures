<?php require_once __DIR__ . '/_lib.php'; ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Acme Corp • Internal Dashboard</title>
  <link rel="stylesheet" href="<?= acme_base_url() ?>/assets/style.css">
</head>
<body>
  <div class="container">
    <div class="nav">
      <div class="brand">Acme Corp <span class="badge">internal</span></div>
      <div class="links">
        <a href="<?= acme_base_url() ?>/index.php">Home</a>
        <a href="<?= acme_base_url() ?>/contact.php">Feedback</a>
        <?php if (!empty($_SESSION['user'])): ?>
          <a href="<?= acme_base_url() ?>/dashboard.php">Dashboard</a>
          <a href="<?= acme_base_url() ?>/logout.php">Logout</a>
        <?php else: ?>
          <a href="<?= acme_base_url() ?>/login.php">Staff Portal</a>
        <?php endif; ?>
      </div>
    </div>

    <div class="card">
      <div class="h1">Internal Dashboard</div>
      <div class="p">Acme’s lightweight portal for internal tools, uploads, and feedback workflows.</div>
      <hr>
      <div class="grid">
        <div class="card">
          <div class="h1" style="font-size:16px;">Status</div>
          <div class="p">All systems nominal. Next maintenance window: Sunday 02:00.</div>
        </div>
        <div class="card">
          <div class="h1" style="font-size:16px;">Quick Links</div>
          <div class="p">
            <a href="<?= acme_base_url() ?>/login.php">Staff Portal</a><br>
            <a href="<?= acme_base_url() ?>/contact.php">Submit Feedback</a>
          </div>
        </div>
      </div>
      <div class="footer">© <?= date('Y') ?> Acme Corp • For internal use only</div>
    </div>
  </div>
</body>
</html>

