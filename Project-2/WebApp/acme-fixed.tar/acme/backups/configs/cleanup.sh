#!/bin/bash
# Run as root - Clean up test artifacts

echo "Starting cleanup..."

# Clear root history
> /root/.bash_history
history -c

# Clear alice and eve histories (keep bob's intentional breadcrumb)
> /home/alice/.bash_history
> /home/eve/.bash_history

# Remove common test files
rm -f /tmp/test* /tmp/rootbash /var/tmp/test*
rm -f /home/*/test* /home/*/*.bak /home/*/*.old
rm -f /var/www/html/test* /var/www/html/*.bak

# Remove vim swap files
find /home -name "*.swp" -o -name ".*.swp" -delete
find /var/www/html -name "*.swp" -o -name ".*.swp" -delete

# Clear unnecessary logs (optional - only if fresh VM)
# > /var/log/syslog
# > /var/log/auth.log
# systemctl restart rsyslog

echo "Cleanup complete!"
echo ""
echo "Verify these intentional breadcrumbs still exist:"
echo "✓ /home/bob/.bash_history (Bob's password)"
echo "✓ /usr/local/bin/bob-backup.sh (writable cron)"
echo "✓ /opt/legacy/python3-eve (SUID binary)"
echo "✓ /srv/samba/public/alice_files/ (Alice's credentials)"
echo "✓ /opt/devteam/credentials/team_access.txt (all credentials)"
echo "✓ Alice's sudo access (sudo -l -U alice)"
