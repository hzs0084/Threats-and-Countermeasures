<?php
require_once __DIR__ . '/_lib.php';
acme_require_login();

// Configuration
$MSG_FILE = __DIR__ . '/data/messages.txt';

$err = '';
$ok = '';

// Handle Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $msg = $_POST['message'] ?? '';
    
    if (trim($msg) === '') {
        $err = 'Message cannot be empty.';
    } else {
        // VULNERABILITY: Storing input exactly as received (no sanitization).
        // In a real app, you might sanitize here OR on output.
        // We are doing neither.
        
        $user = $_SESSION['user'];
        $ts = date('Y-m-d H:i:s');
        
        // Format: timestamp|user|message
        // We base64 encode the message slightly to avoid breaking the file structure with newlines,
        // BUT we will decode it raw on the admin side.
        // (Alternatively, we can just replace newlines to keep it simple).
        $cleanMsg = str_replace(["\r", "\n", "|"], [" ", " ", " "], $msg);
        
        $line = "$ts|$user|$cleanMsg\n";
        
        file_put_contents($MSG_FILE, $line, FILE_APPEND);
        $ok = 'Message sent to Administrator.';
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Acme • Contact Support</title>
  <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
  <div class="container">
    <div class="nav">
      <div class="brand">Acme Corp <span class="badge">support</span></div>
      <div class="links">
        <a href="/">Home</a>
        <a href="/dashboard.php">Dashboard</a>
        <a href="/logout.php">Logout</a>
      </div>
    </div>

    <div class="card">
      <div class="h1">Contact Admin</div>
      <div class="p">
        Found a bug? Need access to the backup server? Leave a message for the admin.
      </div>

      <?php if ($ok): ?>
        <div class="card" style="border-color:#2b5a2a;background:rgba(43,90,42,0.25);">
            <?= htmlspecialchars($ok) ?>
        </div>
      <?php endif; ?>

      <form method="post">
        <label>Message</label>
        <textarea name="message" rows="5" required placeholder="Describe your issue..."></textarea>
        <button type="submit">Send Message</button>
      </form>
    </div>
  </div>
</body>
</html>
