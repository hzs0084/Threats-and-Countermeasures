<?php
require_once __DIR__ . '/_lib.php';

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $u = trim($_POST['username'] ?? '');
  $p = trim($_POST['password'] ?? '');

  $users = acme_read_users(__DIR__ . '/data/users.txt');
  if (isset($users[$u]) && hash_equals($users[$u]['pass'], $p)) {
    $_SESSION['user'] = $u;
    $_SESSION['role'] = $users[$u]['role'];
    header('Location: ' . acme_base_url() . '/dashboard.php');
    exit;
  }
  $err = 'Invalid username or password.';
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Acme • Staff Login</title>
  <link rel="stylesheet" href="<?= acme_base_url() ?>/assets/style.css">
</head>
<body>
  <div class="container">
    <div class="nav">
      <div class="brand">Acme Corp <span class="badge">staff portal</span></div>
      <div class="links">
        <a href="<?= acme_base_url() ?>/index.php">Home</a>
      </div>
    </div>

    <div class="card">
      <div class="h1">Staff Login</div>
      <div class="p">Use your Acme credentials.</div>

      <?php if ($err): ?>
        <div class="card" style="border-color:#5a2a2a;background:rgba(90,42,42,0.25);">
          <?= acme_h($err) ?>
        </div>
      <?php endif; ?>

      <form method="post">
        <label>Username</label>
        <input name="username" autocomplete="username" required>

        <label>Password</label>
        <input name="password" type="password" autocomplete="current-password" required>

        <button type="submit">Sign in</button>
      </form>
    </div>
  </div>
</body>
</html>

