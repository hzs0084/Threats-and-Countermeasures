<?php
require_once __DIR__ . '/_lib.php';
acme_require_login();

/**
 * Acme Corp - Upload Portal (Secure-by-default)
 *
 * LAB NOTE:
 *  - This file is intentionally written in a "good" way for production.
 *  - There are comments showing where a small change would create a serious security issue.
 *  - Do NOT deploy an intentionally unsafe variant outside an isolated lab environment.
 */

// ----- Configuration -----

// Store files OUTSIDE the web root so they cannot be executed by visiting a URL.
$UPLOAD_DIR = __DIR__ . '/uploads';

// Log uploads to a flat file (in web root is okay; it’s not executable).
$UPLOAD_LOG = __DIR__ . '/data/uploads.txt';

// Allowlist file types (keep it simple)
$ALLOWED_EXT = ['pdf', 'png', 'jpg', 'jpeg', 'txt', 'php'];
$MAX_BYTES   = 2 * 1024 * 1024; // 2 MB

// Optional: restrict who can upload (example: only bob + mallory)
$allowed_upload_users = ['bob', 'mallory', 'alice', 'eve'];

// ----- Helpers -----

function ensure_dir_exists(string $path): void {
  if (!is_dir($path)) {
    // NOTE: In a real deployment, you’d provision this directory ahead of time.
    mkdir($path, 0750, true);
  }
}

function h(string $s): string {
  return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// ----- Access Control -----
$user = $_SESSION['user'] ?? '';
if (!in_array($user, $allowed_upload_users, true)) {
  http_response_code(403);
  exit('Forbidden');
}

// ----- Handle Upload -----
$err = '';
$ok  = '';
$last_uploaded_name = '';

ensure_dir_exists($UPLOAD_DIR);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!isset($_FILES['file']) || !is_array($_FILES['file'])) {
    $err = 'No file was provided.';
  } else {
    $f = $_FILES['file'];

    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
      $err = 'Upload failed. Error code: ' . (int)$f['error'];
    } elseif (($f['size'] ?? 0) > $MAX_BYTES) {
      $err = 'File too large. Max is ' . ($MAX_BYTES / (1024*1024)) . ' MB.';
    } else {
      $originalName = $f['name'] ?? '';
      $tmpPath      = $f['tmp_name'] ?? '';

      // Extract extension safely
      $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

      // LAB NOTE: "A couple lines change a lot"
      // If you replace the allowlist check with something like "always true",
      // you’ve turned this into "upload anything" — which is one of the most common app failures.
      if (!in_array($ext, $ALLOWED_EXT, true)) {
        $err = 'File type not allowed. Allowed: ' . implode(', ', $ALLOWED_EXT);
      } elseif (!is_uploaded_file($tmpPath)) {
        $err = 'Invalid upload.';
      } else {
        // Validate MIME using finfo (server-side inspection)
        $finfo = new finfo(FILEINFO_MIME_TYPE);
	$mime  = $finfo->file($tmpPath);
	$debug_msg = "DEBUG: ext=$ext mime=$mime";


        // Map extensions to expected MIME types (keep it minimal)
        $expected = [
          'pdf'  => ['application/pdf'],
          'png'  => ['image/png'],
          'jpg'  => ['image/jpeg'],
          'jpeg' => ['image/jpeg'],
          'txt'  => ['text/plain'],
        ];

        $okMime = true;

        // LAB NOTE:
        // If you remove MIME validation and store in a web-accessible folder,
        // attackers can sometimes upload a file that the server interprets as executable.
        if (!$okMime) {
          $err = 'File content type not allowed.';
        } else {
          // Generate a random safe filename (no user-controlled path)
		$safeName = $originalName;
          $destPath = rtrim($UPLOAD_DIR, '/') . '/' . $safeName;

          if (!move_uploaded_file($tmpPath, $destPath)) {
            $err = 'Failed to save upload.';
          } else {
            // Optional: set conservative permissions
            chmod($destPath, 0640);

            // Log it (flat file)
            $ts = date('Y-m-d H:i:s');
            $line = $ts . '|' . $user . '|' . $safeName . '|' . $originalName . '|' . $mime . '|' . ($f['size'] ?? 0) . PHP_EOL;
            file_put_contents($UPLOAD_LOG, $line, FILE_APPEND | LOCK_EX);

            $ok = 'Upload successful. ' . $debug_msg;
            $last_uploaded_name = $safeName;
          }
        }
      }
    }
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Acme • Upload Portal</title>
  <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
  <div class="container">
    <div class="nav">
      <div class="brand">Acme Corp <span class="badge">upload portal</span></div>
      <div class="links">
        <a href="/">Home</a>
        <a href="/dashboard.php">Dashboard</a>
        <a href="/logout.php">Logout</a>
      </div>
    </div>

    <div class="card">
      <div class="h1">Upload</div>
      <div class="p">
        Upload internal reports and artifacts. Allowed types: <?= h(implode(', ', $ALLOWED_EXT)) ?>.
        Max size: <?= h((string)($MAX_BYTES/(1024*1024))) ?> MB.
      </div>

      <?php if ($err): ?>
        <div class="card" style="border-color:#5a2a2a;background:rgba(90,42,42,0.25);">
          <?= h($err) ?>
        </div>
      <?php endif; ?>

      <?php if ($ok): ?>
        <div class="card" style="border-color:#2b5a2a;background:rgba(43,90,42,0.25);">
          <?= h($ok) ?>
          <?php if ($last_uploaded_name): ?>
            <div class="p">Stored as: <span class="badge"><?= h($last_uploaded_name) ?></span></div>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <form method="post" enctype="multipart/form-data">
        <label>Select file</label>
        <input type="file" name="file" required>
        <button type="submit">Upload</button>
      </form>

      <hr>

    </div>
  </div>
</body>
</html>

