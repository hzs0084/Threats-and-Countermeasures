<?php
require_once __DIR__ . '/../_lib.php';
acme_require_login();

// Simple Admin Check
// In a real lab, you might have a separate admin login or session flag.
// For now, we'll assume anyone accessing this *is* the admin (simulated),
// OR you can log in as 'admin' to test it.
$user = $_SESSION['user'];

// Configuration
$MSG_FILE = __DIR__ . '/../data/messages.txt';
$messages = [];

if (file_exists($MSG_FILE)) {
    $lines = file($MSG_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $parts = explode('|', $line, 3);
        if (count($parts) === 3) {
            $messages[] = [
                'ts' => $parts[0],
                'user' => $parts[1],
                'msg' => $parts[2]
            ];
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Acme • Admin Panel</title>
  <link rel="stylesheet" href="/assets/style.css">
  <style>
    .msg-item { border-bottom: 1px solid #444; padding: 10px 0; }
    .meta { font-size: 0.85em; color: #888; margin-bottom: 4px; }
    .body { font-size: 1.1em; }
  </style>
</head>
<body>
  <div class="container">
    <div class="nav" style="border-bottom: 2px solid #d22;">
      <div class="brand" style="color:#d22;">ADMIN PANEL</div>
      <div class="links">
        <a href="/">Back to Site</a>
        <a href="/logout.php">Logout</a>
      </div>
    </div>

    <div class="card">
      <div class="h1">Inbox</div>
      <div class="p">Viewing all support tickets.</div>

      <?php if (empty($messages)): ?>
        <p>No messages found.</p>
      <?php else: ?>
        <?php foreach (array_reverse($messages) as $m): ?>
          <div class="msg-item">
            <div class="meta">
                <span><?= htmlspecialchars($m['ts']) ?></span> | 
                <strong style="color:#fff"><?= htmlspecialchars($m['user']) ?></strong> says:
            </div>
            
            <div class="body">
                <?= $m['msg'] ?> 
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
